package object;

public class CampusUser extends User {
    public CampusUser(long id, String firstName, String lastName) {
        super(id, firstName, lastName);
    }
}