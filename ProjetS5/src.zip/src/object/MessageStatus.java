package object;

public enum MessageStatus {
    DEFAULT, RECEIVED_BY_SERVER, RECEIVED_BY_ALL_USERS, READ_BY_ALL_USERS
}