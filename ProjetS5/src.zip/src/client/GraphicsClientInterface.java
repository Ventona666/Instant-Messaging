package client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.Date;
import java.util.NavigableSet;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.border.Border;
import javax.swing.tree.DefaultMutableTreeNode;

import object.Group;
import object.Message;
import object.Thread;
import object.User;
import object.CampusUser;

public class GraphicsClientInterface {

    // Containers
    private JFrame frame;
    private JPanel mainPanel;
    private JPanel leftPanel;
    private JPanel rightPanel;
    private JPanel topLeftPanel;
    private JPanel welcomePanel;
    private JPanel buttonPanel;
    private JPanel bottomPanel;
    private JScrollPane ticketTreeScrollPane;
    private JScrollPane chatScrollPane;
    private JScrollPane textScrollPane;

    private JSplitPane splitPane;

    // Buttons
    private JButton newTicketButton;
    private JButton signOutButton;
    private JButton sendButton;
    private JButton myInfoButton;
    private JButton groupMember;

    // Text area
    private JTextArea textArea;

    // other components
    private JTree ticketTree;
    private JTable messageTable;
    private JLabel usernameLabel;

    private String username;
    private User user;

    private Color blue = new Color(16, 79, 85, 255);

    public GraphicsClientInterface(User user) {
        this.user = user;
        username = user.getFirstName() + " " + user.getLastName();
        // buildTree(user);
        buildComponents();
        // leftPanel.add(ticketTree, BorderLayout.SOUTH);

        build();
    }

    private void buildComponents() {
        frame = new JFrame();
        mainPanel = new JPanel();
        bottomPanel = new JPanel();
        textArea = new JTextArea(2, 55);
        textArea.setLineWrap(true);
        sendButton = new JButton("Envoyer");
        sendButton.setForeground(Color.WHITE);
        ticketTree = new JTree();

        leftPanel = new JPanel();
        topLeftPanel = new JPanel();

        usernameLabel = new JLabel(username);
        myInfoButton = new JButton("my infos");
        rightPanel = new JPanel();
        // splitPane = new JSplitPane();
    }

    private void setMainFrame() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(1000, 600));
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setUndecorated(true);
        frame.setVisible(true);
        setMainPanel();
        frame.add(mainPanel);
        frame.setContentPane(mainPanel);
    }

    private void setMainPanel() {

        setLeftPanel();
        setTopLeftPanel();
        setRightPanel();
        setBottomPanel();
        setSplitPane();

        mainPanel.add(splitPane);
        mainPanel.setBackground(blue);

    }

    private void setSplitPane() {
        splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);

    }

    private void setBottomPanel() {
        FlowLayout layout = new FlowLayout(FlowLayout.RIGHT);
        bottomPanel.setLayout(layout);
        // textArea.setSize(200, 100); // a modifier
        bottomPanel.add(textArea);
        bottomPanel.add(sendButton);
        // rightPanel.add(bottomPanel,BorderLayout.SOUTH);
        // mainPanel.add(bottomPanel,BorderLayout.SOUTH);

    }

    private void setTopLeftPanel() {
        FlowLayout layout = new FlowLayout();
        topLeftPanel.setLayout(layout);
        topLeftPanel.add(usernameLabel, BorderLayout.NORTH);
        topLeftPanel.add(myInfoButton);

        leftPanel.add(topLeftPanel, BorderLayout.NORTH);

    }

    private void setLeftPanel() {
        BorderLayout layout = new BorderLayout();
        leftPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.black));
        leftPanel.setLayout(layout);
        JTree threadTree = buildTree(user);
        leftPanel.add(threadTree, BorderLayout.SOUTH);
        // ticketTreeScrollPane.add(buildTree(user));
        // leftPanel.add(ticketTreeScrollPane, BorderLayout.CENTER);
        // ticketTreeScrollPane.setBackground(blue);

        // leftPanel.add(topLeftPanel,BorderLayout.NORTH);
        mainPanel.add(leftPanel, BorderLayout.WEST);

    }

    private void setRightPanel() {
        BorderLayout layout = new BorderLayout();
        rightPanel.setLayout(layout);
        setBottomPanel();
        rightPanel.add(bottomPanel, BorderLayout.SOUTH);
        mainPanel.add(rightPanel, BorderLayout.SOUTH);

    }

    public JTree buildTree(User user) {

        NavigableSet<Group> groupList;
        DefaultMutableTreeNode groups = new DefaultMutableTreeNode("Groupes");
        DefaultMutableTreeNode groupp = new DefaultMutableTreeNode("test");
        groups.add(groupp);
        groupList = user.getGroupList();
        for (Group group : groupList) {
            DefaultMutableTreeNode groupTemp = new DefaultMutableTreeNode(group.getName());
            groups.add(groupTemp);
            for (Thread thread : group.getThreadList()) {
                DefaultMutableTreeNode threadTemp = new DefaultMutableTreeNode(thread.getTitle());
                groupTemp.add(threadTemp);
            }
        }
        ticketTree = new JTree(groups);
        // ticketTreeScrollPane = new JScrollPane(ticketTree,
        // JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
        // JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        // ticketTree.setBackground(Color.darkGray);
        // leftPanel.add(ticketTree, BorderLayout.SOUTH);
        // f.add(ticketTree);
        // f.setSize(200, 200);
        // f.setVisible(true);
        // ticketTreeScrollPane.setBackground(blue);
        // ticketTreeScrollPane.add(ticketTree);
        // leftPanel.add(ticketTreeScrollPane, BorderLayout.PAGE_END);
        return ticketTree;
    }

    public void build() {
        buildComponents();
        setMainFrame();

        frame.setVisible(true);

    }

    public static void main(String[] args) {
        CampusUser user = new CampusUser(1, "Sabrina", "Sikder");
        CampusUser user2 = new CampusUser(2, "Hugo", "Deleye");
        Group student = new Group(0, "Étudiant");
        Group grp1 = new Group(1, "TDA1");
        Group grp2 = new Group(2, "TDA2");
        Group grp3 = new Group(3, "TDA3");
        Group grp4 = new Group(4, "TDA4");
        Group grp5 = new Group(5, "TDA5");
        user.addGroup(grp1);
        grp1.addUser(user);
        user.addGroup(grp2);
        grp2.addUser(user);
        user.addGroup(grp3);
        grp3.addUser(user);
        user.addGroup(grp4);
        grp4.addUser(user);
        user.addGroup(grp5);
        grp5.addUser(user);
        user.addGroup(student);
        student.addUser(user);
        user2.addGroup(grp2);
        grp2.addUser(user2);
        user2.addGroup(student);
        student.addUser(user2);
        Thread th1 = new Thread(1, "J'ai des soucis avec Christine Sénac", user, grp4);
        grp4.addThread(th1);
        th1.addMessage(new Message(1, new Date(), user, "Christine arrête pas de m'embeter", th1));
        Thread th2 = new Thread(2, "caca", user, student);
        student.addThread(th2);
        th2.addMessage(new Message(2, new Date(), user, "J'ai fait caca sur une des tables de l'U3-03 !", th2));
        Thread th3 = new Thread(3, "title title title title title title title title title", user2, grp1);
        grp1.addThread(th3);
        th3.addMessage(new Message(3, new Date(), user2,
                "Je ne savais pas quoi mettre comme titre du coup j'ai mis ça mais je suis pas sûr du titre", th3));
        GraphicsClientInterface g1 = new GraphicsClientInterface(user);
        // g1.build();

    }
}