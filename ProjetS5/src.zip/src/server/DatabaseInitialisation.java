package server;

public class DatabaseInitialisation {

    public DatabaseInitialisation() {

    }

    public static void main(String[] args) {

    }

}
²