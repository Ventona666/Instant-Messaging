package server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NavigableSet;

import object.CampusUser;
import object.Group;
import object.Message;
import object.StaffUser;
import object.User;
import object.Thread;

public class DatabaseInteraction {

    private String dbUrl;
    private static final String DB_IP = "51.77.148.156";
    private static final String DB_PROT = "jdbc:mysql:";
    private static final String DB_PORT = "3306";
    private static final String DB_NAME = "projet";
    private static final String DB_USER = "projet";
    private static final String DB_PASS = "ProjetS5!";

    public DatabaseInteraction() {

        dbUrl = DB_PROT + "//" + DB_IP + ":" + DB_PORT + "/" + DB_NAME;
        // con = DriverManager.getConnection(dbUrl, DB_USER, DB_PASS);

    }

    public Thread getThread(long idThread) {
        String req = "SELECT * FROM Thread WHERE id=" + idThread;
        try (Connection con = DriverManager.getConnection(dbUrl, DB_USER, DB_PASS);
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(req);) {
            Group group = getGroup(rs.getLong("idGroup"));
            User user = getUser(rs.getLong("idUser"));
            return new Thread(idThread, rs.getString("title"), user, group);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Message getMessage(long idMessage) {
        String req = "SELECT * FROM Message WHERE id=" + idMessage;
        try (Connection con = DriverManager.getConnection(dbUrl, DB_USER, DB_PASS);
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(req);) {
            return new Message(idMessage, null, null, rs.getString("testMessage"), null);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public User getUser(long idUser) {
        User user;
        String req = "SELECT * FROM User WHERE id=" + idUser;
        try (Connection con = DriverManager.getConnection(dbUrl, DB_USER, DB_PASS);
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(req);) {
            String firstName = rs.getString("firstNameUser");
            String lastName = rs.getString("lastNameUser");
            if (rs.getString("typeUser").equals("campus"))
                user = new CampusUser(idUser, firstName, lastName);
            else
                user = new StaffUser(idUser, firstName, lastName);
            user.setGroupList(getGroupUser(idUser));
            return user;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    private NavigableSet<Group> getGroupUser(long idUser) {
        NavigableSet<Group> listGroup;
        String req = "SELECT idGroup FROM Member WHERE idUser=" + idUser;
        try(Connection con = DriverManager.getConnection(dbUrl, DB_USER, DB_PASS);
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(req);) {
            while(rs.next()) {
                listGroup.add(getGroup(rs.getLong("idGroup")));
            }
            return listGroup;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public NavigableSet<Group> getAllGroup() {
        NavigableSet<Group> listGroup;
        String req = "SELECT idGroup FROM Group";
        try(Connection con = DriverManager.getConnection(dbUrl, DB_USER, DB_PASS);
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(req);) {
            while(rs.next()) {
                listGroup.add(getGroup(rs.getLong("idGroup")));
            }
            return listGroup;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Group getGroup(long idGroup) {
        String req = "SELECT * FROM Group WHERE id=" + idGroup;
        try (Connection con = DriverManager.getConnection(dbUrl, DB_USER, DB_PASS);
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(req);) {
            String firstName = rs.getString("firstNameUser");
            String lastName = rs.getString("lastNameUser");
            if (rs.getString("typeUser").equals("campus"))
                return new CampusUser(idUser, firstName, lastName);
            else
                return new StaffUser(idUser, firstName, lastName);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public
}
