package server;

public class TestDatabase {

    DatabaseInteraction database;

    public TestDatabase() {
        database = new DatabaseInteraction();
    }

}
